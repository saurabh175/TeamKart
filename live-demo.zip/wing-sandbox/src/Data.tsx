import React from "react";
import Drop from "./Drop"
function Workshop() {
    return (<div style={{ display: "flex", justifyContent: "center", padding: '2rem', width: "100%", textAlign: "center"}} ><Drop/></div>);
}

export default Workshop;