import React from "react";
import Chat from "./Chat";
import { Container, TextInput, Loader, Paper, Slider, Switch } from '@mantine/core';
function Workshop() {
    return (<div><Chat/></div>);
}

export default Workshop;